# Pseudocode for Context-Sensitive Apriori Algorithm

## Algorithm Overview

The Context-Sensitive Apriori algorithm enhances traditional Apriori by incorporating contextual information into the pattern mining process.

## Main Algorithm

```pseudocode
Algorithm ContextSensitiveApriori {
    Input: 
        D: List<Transaction>      // transaction database
        minSup: Float            // minimum support threshold
        minConf: Float          // minimum confidence threshold
    Output: 
        R: List<Rule>           // generated rules

    // Main Algorithm
    Function Mine() {
        // 1. Group transactions by context
        contexts = GroupByContext(D)
        rules = []

        // 2. Process each context separately
        For each (ctx, transactions) in contexts {
            L1 = GetFrequent1Items(transactions, minSup)
            L = {1: L1}
            k = 2

            // 3. Generate frequent itemsets
            While L[k-1] not empty {
                Ck = GenerateCandidates(L[k-1])
                For each t in transactions {
                    For each c in Ck {
                        If c ⊆ t.items {
                            count[c]++
                        }
                    }
                }
                
                // Filter by minSup
                L[k] = {c ∈ Ck | count[c]/|transactions| ≥ minSup}
                k++
            }

            // 4. Generate rules
            For each k in L.keys() where k ≥ 2 {
                For each itemset in L[k] {
                    rules += GenerateRules(itemset, L, ctx, minConf)
                }
            }
        }
        Return rules
    }
}
```

## Helper Functions

### 1. Context Grouping
```pseudocode
Function GroupByContext(transactions) {
    groups = {}
    For each t in transactions {
        key = GetContextKey(t.context)
        groups[key].append(t)
    }
    Return groups
}
```

### 2. Frequent 1-Itemsets
```pseudocode
Function GetFrequent1Items(transactions, minSup) {
    counts = {}
    For each t in transactions {
        For each item in t.items {
            counts[item]++
        }
    }
    Return {item | count/|transactions| ≥ minSup}
}
```

### 3. Candidate Generation
```pseudocode
Function GenerateCandidates(Lk) {
    candidates = {}
    For each i1, i2 in Lk where CanJoin(i1, i2) {
        c = i1 ∪ i2
        If AllSubsetsFrequent(c, Lk) {
            candidates.add(c)
        }
    }
    Return candidates
}
```

### 4. Rule Generation
```pseudocode
Function GenerateRules(itemset, L, ctx, minConf) {
    rules = []
    For each subset in PowerSet(itemset) except ∅ and itemset {
        conf = support(itemset)/support(subset)
        If conf ≥ minConf {
            rules.append(Rule(
                subset,
                itemset - subset,
                ctx,
                support(itemset),
                conf
            ))
        }
    }
    Return rules
}
```

## Algorithm Flow

```mermaid
graph TD
    A[Input Transactions] --> B[Context Grouping]
    B --> C[For Each Context]
    C --> D[Generate 1-Itemsets]
    D --> E[Generate k-Itemsets]
    E --> F[Generate Rules]
    F --> G[Combine Results]
    G --> H[Output Rules]
```

## Key Features

1. **Context Awareness**
   - Transaction grouping by context
   - Context-specific support calculation
   - Contextual rule generation

2. **Efficiency Measures**
   - Early candidate pruning
   - Context-based parallelization
   - Optimized support counting

3. **Rule Quality**
   - Context-specific confidence
   - Support adjustment by context
   - Pattern relevance scoring 