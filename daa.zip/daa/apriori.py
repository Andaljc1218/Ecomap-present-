from collections import defaultdict
from itertools import combinations

class Apriori:
    def __init__(self, min_support=0.5, min_confidence=0.7):
        """
        Initialize Apriori algorithm with minimum support and confidence thresholds
        
        Args:
            min_support (float): Minimum support threshold (0 to 1)
            min_confidence (float): Minimum confidence threshold (0 to 1)
        """
        self.min_support = min_support
        self.min_confidence = min_confidence
        self.itemsets = []
        self.rules = []

    def _get_support(self, itemset, transactions):
        """Calculate support for an itemset"""
        count = sum(1 for transaction in transactions if itemset.issubset(transaction))
        return count / len(transactions)

    def _get_frequent_1_itemsets(self, transactions):
        """Find all frequent 1-itemsets"""
        items = defaultdict(int)
        for transaction in transactions:
            for item in transaction:
                items[frozenset([item])] += 1
        
        # Filter items based on minimum support
        n = len(transactions)
        return {item: count/n for item, count in items.items() 
                if count/n >= self.min_support}

    def _generate_candidates(self, prev_frequent, k):
        """Generate candidate k-itemsets from frequent (k-1)-itemsets"""
        candidates = set()
        for item1 in prev_frequent:
            for item2 in prev_frequent:
                union = item1.union(item2)
                if len(union) == k and union not in candidates:
                    candidates.add(union)
        return candidates

    def fit(self, transactions):
        """
        Find frequent itemsets and generate association rules
        
        Args:
            transactions (list): List of transactions where each transaction is a set of items
        """
        # Find frequent 1-itemsets
        frequent = self._get_frequent_1_itemsets(transactions)
        k = 2
        self.itemsets = [frequent]

        # Find frequent k-itemsets
        while frequent:
            candidates = self._generate_candidates(frequent.keys(), k)
            frequent = {}
            
            for candidate in candidates:
                support = self._get_support(candidate, transactions)
                if support >= self.min_support:
                    frequent[candidate] = support
            
            if frequent:
                self.itemsets.append(frequent)
            k += 1

        # Generate association rules
        self.rules = []
        for k_itemsets in self.itemsets[1:]:  # Skip 1-itemsets
            for itemset in k_itemsets:
                for i in range(1, len(itemset)):
                    for antecedent in combinations(itemset, i):
                        antecedent = frozenset(antecedent)
                        consequent = itemset - antecedent
                        
                        # Calculate confidence
                        confidence = k_itemsets[itemset] / self._get_support(antecedent, transactions)
                        
                        if confidence >= self.min_confidence:
                            support = k_itemsets[itemset]
                            self.rules.append((antecedent, consequent, support, confidence))

    def get_frequent_itemsets(self):
        """Return all frequent itemsets with their support values"""
        return self.itemsets

    def get_rules(self):
        """Return all association rules with their support and confidence values"""
        return self.rules


# Example usage
if __name__ == "__main__":
    # Sample transaction database
    transactions = [
        {'bread', 'milk'},
        {'bread', 'diaper', 'beer', 'eggs'},
        {'milk', 'diaper', 'beer', 'cola'},
        {'bread', 'milk', 'diaper', 'beer'},
        {'bread', 'milk', 'diaper', 'cola'}
    ]

    # Initialize Apriori with minimum support of 0.3 and minimum confidence of 0.7
    apriori = Apriori(min_support=0.3, min_confidence=0.7)
    
    # Find frequent itemsets and association rules
    apriori.fit(transactions)
    
    # Print frequent itemsets
    print("Frequent Itemsets:")
    for k, itemsets in enumerate(apriori.get_frequent_itemsets(), 1):
        print(f"\n{k}-itemsets:")
        for itemset, support in itemsets.items():
            print(f"Items: {set(itemset)}, Support: {support:.2f}")
    
    # Print association rules
    print("\nAssociation Rules:")
    for antecedent, consequent, support, confidence in apriori.get_rules():
        print(f"{set(antecedent)} -> {set(consequent)}")
        print(f"Support: {support:.2f}, Confidence: {confidence:.2f}\n") 