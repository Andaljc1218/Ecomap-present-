import unittest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Tuple
import matplotlib.pyplot as plt
import seaborn as sns

from src.algorithm.traditional_apriori import AprioriAlgorithm
from src.algorithm.context_sensitive_apriori import (
    ContextSensitiveApriori,
    ContextualTransaction,
    ContextMetadata
)

class ComparativeAnalysis:
    def __init__(self):
        self.results = {
            'traditional': {},
            'context_sensitive': {}
        }

    def generate_retail_dataset(self) -> Tuple[List[List[str]], List[ContextualTransaction]]:
        """Generate a realistic retail dataset with temporal and demographic patterns."""
        # Product categories
        products = {
            'morning': ['coffee', 'bread', 'eggs', 'newspaper', 'milk'],
            'afternoon': ['sandwich', 'soda', 'snacks', 'fruits'],
            'evening': ['dinner_ingredients', 'wine', 'dessert', 'meat']
        }
        
        # Customer segments
        segments = {
            'young_professional': {
                'morning': ['coffee', 'sandwich'],
                'evening': ['ready_meals', 'wine']
            },
            'family': {
                'morning': ['bread', 'milk', 'eggs'],
                'afternoon': ['snacks', 'fruits'],
                'evening': ['dinner_ingredients', 'meat']
            },
            'senior': {
                'morning': ['newspaper', 'bread'],
                'afternoon': ['fruits', 'tea'],
                'evening': ['dinner_ingredients']
            }
        }

        # Generate transactions
        traditional_transactions = []
        contextual_transactions = []
        
        # Simulate 30 days of transactions
        start_date = datetime.now() - timedelta(days=30)
        
        for day in range(30):
            current_date = start_date + timedelta(days=day)
            
            # Generate transactions for different times of day
            for time_of_day in ['morning', 'afternoon', 'evening']:
                # Generate transactions for each customer segment
                for segment in segments.keys():
                    # Generate 3-5 transactions per segment per time period
                    num_transactions = np.random.randint(3, 6)
                    
                    for _ in range(num_transactions):
                        # Base items from time period
                        base_items = np.random.choice(
                            products[time_of_day],
                            size=np.random.randint(2, 4),
                            replace=False
                        )
                        
                        # Add segment-specific items
                        if time_of_day in segments[segment]:
                            segment_items = np.random.choice(
                                segments[segment][time_of_day],
                                size=np.random.randint(1, 3),
                                replace=False
                            )
                            items = list(set(base_items) | set(segment_items))
                        else:
                            items = list(base_items)

                        # Create traditional transaction
                        traditional_transactions.append(items)
                        
                        # Create contextual transaction
                        context = ContextMetadata(
                            temporal={
                                'time_of_day': time_of_day,
                                'day_of_week': current_date.strftime('%A').lower(),
                                'season': 'summer'  # Simplified for example
                            },
                            spatial={
                                'location_type': 'supermarket',
                                'region': np.random.choice(['urban', 'suburban', 'rural'])
                            },
                            user={
                                'demographic': segment,
                                'behavior_segment': 'regular'
                            }
                        )
                        
                        contextual_transactions.append(
                            ContextualTransaction(
                                items=items,
                                context=context,
                                timestamp=current_date
                            )
                        )
        
        return traditional_transactions, contextual_transactions

    def run_comparative_analysis(self):
        """Run comprehensive comparative analysis."""
        # Generate dataset
        trad_trans, ctx_trans = self.generate_retail_dataset()
        
        # Test different support and confidence thresholds
        thresholds = [
            (0.1, 0.5, "Low thresholds"),
            (0.2, 0.6, "Medium thresholds"),
            (0.3, 0.7, "High thresholds")
        ]
        
        for min_sup, min_conf, desc in thresholds:
            print(f"\nRunning analysis with {desc}")
            print(f"Support: {min_sup}, Confidence: {min_conf}")
            
            # Traditional Apriori
            trad_start = datetime.now()
            trad_apriori = AprioriAlgorithm(min_support=min_sup, min_confidence=min_conf)
            trad_apriori.fit(trad_trans)
            trad_rules = trad_apriori.get_rules()
            trad_time = (datetime.now() - trad_start).total_seconds()
            
            # Context-sensitive Apriori
            ctx_start = datetime.now()
            ctx_apriori = ContextSensitiveApriori(min_support=min_sup, min_confidence=min_conf)
            ctx_apriori.fit(ctx_trans)
            ctx_rules = ctx_apriori.get_rules()
            ctx_time = (datetime.now() - ctx_start).total_seconds()
            
            # Store results
            self.results['traditional'][desc] = {
                'execution_time': trad_time,
                'num_rules': len(trad_rules),
                'rules': trad_rules
            }
            
            self.results['context_sensitive'][desc] = {
                'execution_time': ctx_time,
                'num_rules': len(ctx_rules),
                'rules': ctx_rules,
                'stats': ctx_apriori.get_performance_stats()
            }
            
            # Print comparative results
            print("\nResults:")
            print(f"Traditional Apriori:")
            print(f"- Execution time: {trad_time:.3f} seconds")
            print(f"- Number of rules: {len(trad_rules)}")
            
            print(f"\nContext-sensitive Apriori:")
            print(f"- Execution time: {ctx_time:.3f} seconds")
            print(f"- Number of rules: {len(ctx_rules)}")
            print("\nDetailed metrics:")
            for metric, value in ctx_apriori.get_performance_stats().items():
                print(f"- {metric}: {value:.3f}")

    def analyze_rule_quality(self):
        """Analyze the quality and relevance of generated rules."""
        for desc in self.results['traditional'].keys():
            trad_rules = self.results['traditional'][desc]['rules']
            ctx_rules = self.results['context_sensitive'][desc]['rules']
            
            print(f"\nRule Analysis for {desc}")
            print("=" * 50)
            
            # Analyze rule distribution
            print("\nRule Distribution:")
            print(f"Traditional: {len(trad_rules)} total rules")
            print(f"Context-sensitive: {len(ctx_rules)} total rules")
            
            # Analyze support and confidence distributions
            trad_supports = [sup for _, _, sup, _ in trad_rules]
            trad_confidences = [conf for _, _, _, conf in trad_rules]
            
            ctx_supports = [sup for _, _, sup, _ in ctx_rules]
            ctx_confidences = [conf for _, _, _, conf in ctx_rules]
            
            print("\nSupport Statistics:")
            print(f"Traditional - Avg: {np.mean(trad_supports):.3f}, Std: {np.std(trad_supports):.3f}")
            print(f"Context - Avg: {np.mean(ctx_supports):.3f}, Std: {np.std(ctx_supports):.3f}")
            
            print("\nConfidence Statistics:")
            print(f"Traditional - Avg: {np.mean(trad_confidences):.3f}, Std: {np.std(trad_confidences):.3f}")
            print(f"Context - Avg: {np.mean(ctx_confidences):.3f}, Std: {np.std(ctx_confidences):.3f}")

    def visualize_results(self):
        """Create visualizations comparing the algorithms."""
        # Prepare data for plotting
        thresholds = list(self.results['traditional'].keys())
        trad_times = [self.results['traditional'][t]['execution_time'] for t in thresholds]
        ctx_times = [self.results['context_sensitive'][t]['execution_time'] for t in thresholds]
        trad_rules = [self.results['traditional'][t]['num_rules'] for t in thresholds]
        ctx_rules = [self.results['context_sensitive'][t]['num_rules'] for t in thresholds]

        # Create subplots
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))

        # Execution Time Comparison
        x = np.arange(len(thresholds))
        width = 0.35

        ax1.bar(x - width/2, trad_times, width, label='Traditional')
        ax1.bar(x + width/2, ctx_times, width, label='Context-Sensitive')
        ax1.set_ylabel('Execution Time (seconds)')
        ax1.set_title('Execution Time Comparison')
        ax1.set_xticks(x)
        ax1.set_xticklabels(thresholds)
        ax1.legend()

        # Number of Rules Comparison
        ax2.bar(x - width/2, trad_rules, width, label='Traditional')
        ax2.bar(x + width/2, ctx_rules, width, label='Context-Sensitive')
        ax2.set_ylabel('Number of Rules')
        ax2.set_title('Rules Generated Comparison')
        ax2.set_xticks(x)
        ax2.set_xticklabels(thresholds)
        ax2.legend()

        plt.tight_layout()
        plt.savefig('comparison_results.png')
        plt.close()

def main():
    # Run analysis
    analysis = ComparativeAnalysis()
    
    print("Generating and analyzing retail dataset...")
    analysis.run_comparative_analysis()
    
    print("\nAnalyzing rule quality...")
    analysis.analyze_rule_quality()
    
    print("\nGenerating visualizations...")
    analysis.visualize_results()
    
    print("\nAnalysis complete! Check 'comparison_results.png' for visualizations.")

if __name__ == "__main__":
    main() 