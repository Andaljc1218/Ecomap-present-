import unittest
from src.algorithm.traditional_apriori import AprioriAlgorithm

class TestAprioriAlgorithm(unittest.TestCase):
    def setUp(self):
        # Sample transaction database for testing
        self.transactions = [
            ["bread", "milk", "eggs", "butter"],
            ["bread", "milk", "butter"],
            ["milk", "butter", "eggs"],
            ["bread", "milk", "butter", "jam"],
            ["bread", "milk"],
            ["bread", "jam"],
            ["milk", "butter", "jam"],
            ["bread", "milk", "butter", "eggs"],
            ["bread", "milk", "eggs"],
            ["butter", "jam"]
        ]
        
    def test_basic_functionality(self):
        # Test with moderate thresholds
        apriori = AprioriAlgorithm(min_support=0.3, min_confidence=0.5)
        apriori.fit(self.transactions)
        rules = apriori.get_rules()
        
        # Verify that rules were generated
        self.assertTrue(len(rules) > 0)
        
        # Verify rule format
        for antecedent, consequent, support, confidence in rules:
            # Check types
            self.assertIsInstance(antecedent, frozenset)
            self.assertIsInstance(consequent, frozenset)
            self.assertIsInstance(support, float)
            self.assertIsInstance(confidence, float)
            
            # Check value ranges
            self.assertGreaterEqual(support, 0.3)
            self.assertGreaterEqual(confidence, 0.5)
            self.assertLessEqual(support, 1.0)
            self.assertLessEqual(confidence, 1.0)
    
    def test_high_thresholds(self):
        # Test with high thresholds - should generate fewer rules
        apriori = AprioriAlgorithm(min_support=0.5, min_confidence=0.7)
        apriori.fit(self.transactions)
        high_threshold_rules = apriori.get_rules()
        
        # Test with lower thresholds - should generate more rules
        apriori_low = AprioriAlgorithm(min_support=0.2, min_confidence=0.4)
        apriori_low.fit(self.transactions)
        low_threshold_rules = apriori_low.get_rules()
        
        # Higher thresholds should result in fewer rules
        self.assertLess(len(high_threshold_rules), len(low_threshold_rules))
    
    def test_empty_transactions(self):
        # Test with empty transaction list
        apriori = AprioriAlgorithm(min_support=0.3, min_confidence=0.5)
        apriori.fit([])
        rules = apriori.get_rules()
        
        # Should return empty rules list
        self.assertEqual(len(rules), 0)
    
    def test_single_item_transactions(self):
        # Test with transactions containing only one item each
        single_item_transactions = [
            ["bread"],
            ["milk"],
            ["bread"],
            ["eggs"],
            ["bread"]
        ]
        
        apriori = AprioriAlgorithm(min_support=0.3, min_confidence=0.5)
        apriori.fit(single_item_transactions)
        rules = apriori.get_rules()
        
        # Should not generate any rules (need at least 2 items for a rule)
        self.assertEqual(len(rules), 0)
    
    def test_specific_rules(self):
        # Test for specific expected rules in the sample dataset
        apriori = AprioriAlgorithm(min_support=0.3, min_confidence=0.6)
        apriori.fit(self.transactions)
        rules = apriori.get_rules()
        
        # Convert rules to a more easily searchable format
        rule_pairs = [(set(ant), set(cons)) for ant, cons, sup, conf in rules]
        
        # Check for expected common associations
        self.assertIn(({"bread"}, {"milk"}), rule_pairs)
        self.assertIn(({"butter"}, {"milk"}), rule_pairs)

def print_detailed_results(transactions):
    """Helper function to print detailed results for manual verification."""
    print("\nDetailed Apriori Analysis")
    print("========================")
    
    # Test with different threshold combinations
    thresholds = [
        (0.2, 0.4, "Low thresholds"),
        (0.3, 0.5, "Medium thresholds"),
        (0.5, 0.7, "High thresholds")
    ]
    
    for min_sup, min_conf, desc in thresholds:
        print(f"\n{desc}")
        print(f"Min Support: {min_sup}, Min Confidence: {min_conf}")
        print("-" * 50)
        
        apriori = AprioriAlgorithm(min_support=min_sup, min_confidence=min_conf)
        apriori.fit(transactions)
        rules = apriori.get_rules()
        
        print(f"Number of rules generated: {len(rules)}")
        for antecedent, consequent, support, confidence in rules:
            print(f"\nRule: {set(antecedent)} => {set(consequent)}")
            print(f"Support: {support:.3f}")
            print(f"Confidence: {confidence:.3f}")

if __name__ == '__main__':
    # Run tests
    unittest.main(argv=[''], exit=False)
    
    # Create test instance for detailed analysis
    test_instance = TestAprioriAlgorithm()
    test_instance.setUp()
    
    # Print detailed results
    print_detailed_results(test_instance.transactions) 