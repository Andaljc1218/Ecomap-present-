# Context-Sensitive Apriori Algorithm Analysis

This project implements and analyzes two versions of the Apriori algorithm:
1. Traditional Apriori
2. Context-Sensitive Apriori

## Algorithm Complexity Analysis

### Traditional Apriori
- **Time Complexity**: O(N×M×w + ∑(|L(k-1)|²))
  - N = number of transactions
  - M = number of unique items
  - w = average transaction width
  - |L(k-1)| = size of frequent itemsets at level k-1
- **Space Complexity**: O(NM + w×|C|)
  - |C| = size of candidate set

### Context-Sensitive Apriori
- **Time Complexity**: O(N + C×N×M×w + C×∑(|L(k-1)|²))
  - Additional C factor for context-specific processing
- **Space Complexity**: O(C×NM + C×w×|C| + N×K)
  - K = context-specific parameters

## Complexity Proof

### Traditional Apriori

1. **Initial Scan (1-itemsets)**:
   - Scanning N transactions with average width w: O(N×w)
   - Creating M item counts: O(M)
   - Total: O(N×w + M)

2. **Candidate Generation**:
   - For each k, generating candidates from L(k-1): O(|L(k-1)|²)
   - Total across all k: O(∑(|L(k-1)|²))

3. **Support Counting**:
   - For each transaction (N) and each candidate
   - Total: O(N×M×w)

### Context-Sensitive Apriori

1. **Context Extraction**:
   - Initial scan of N transactions: O(N)

2. **Context-Specific Processing**:
   - For each context C:
     - Initial scan: O(N×w)
     - Candidate generation: O(∑(|L(k-1)|²))
     - Support counting: O(N×M×w)
   - Total: O(C×(N×M×w + ∑(|L(k-1)|²)))

## Key Improvements in Context-Sensitive Version

1. **Contextual Filtering**:
   - Rules are generated specific to contexts
   - Better quality and relevance of rules
   - Reduced false positives

2. **Granular Analysis**:
   - Temporal patterns (time of day, season)
   - Spatial patterns (location type, region)
   - User demographic patterns

3. **Performance Trade-offs**:
   - Higher computational complexity
   - Better rule quality and relevance
   - More storage requirements

## Usage

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Run comparative analysis:
```bash
python tests/comparative_analysis.py
```

## Results

The comparative analysis shows:
1. Context-Sensitive Apriori generates more targeted rules
2. Higher computational cost but better rule quality
3. Improved relevance for specific contexts
4. Better handling of temporal and demographic patterns

# Context-Sensitive Apriori Algorithm Project
## Design and Analysis of Algorithms

### Project Structure
```
.
├── docs/                      # Documentation files
│   ├── abstract.md           # Project abstract
│   ├── introduction.md       # Introduction and background
│   ├── problem.md           # Problem definition
│   ├── literature.md        # Literature review
│   ├── solution.md          # Proposed solution
│   ├── complexity.md        # Complexity analysis
│   ├── implementation.md    # Implementation details
│   ├── results.md           # Experimental results
│   ├── discussion.md        # Discussion
│   └── conclusion.md        # Conclusion
├── src/                      # Source code
│   ├── algorithm/           # Algorithm implementation
│   ├── data/               # Sample datasets
│   └── utils/              # Utility functions
├── tests/                   # Test cases
└── requirements.txt         # Project dependencies
```

### Getting Started
1. Clone the repository
2. Install dependencies: `pip install -r requirements.txt`
3. Run tests: `python -m pytest tests/`

### Documentation
The complete project documentation is available in the `docs/` directory. Each aspect of the project is detailed in separate markdown files for better organization and readability.

### Implementation
The core algorithm is implemented in Python, with the following key components:
- Context-sensitive Apriori algorithm
- Data preprocessing utilities
- Performance evaluation tools
- Visualization helpers

### Authors
[Your Names Here]

### License
MIT License 